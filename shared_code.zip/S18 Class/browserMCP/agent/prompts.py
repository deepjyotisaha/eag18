class SystemPrompt:
    pass
